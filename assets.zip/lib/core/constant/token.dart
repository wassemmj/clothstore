class Token {
  static String token = '';
}