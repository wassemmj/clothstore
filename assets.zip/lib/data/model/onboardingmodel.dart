class OnBoardingModel{
  final String? title;
  final String? image;
  final String? body;
  OnBoardingModel({this.title,this.image,this.body});
}