import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;

import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:myproject/view/screen/comments.dart';

import '../../core/constant/token.dart';

class DetailsScreen extends StatefulWidget {
  const DetailsScreen(
      {Key? key,
      required this.name,
      required this.desc,
      required this.price,
      required this.id})
      : super(key: key);

  final int id;
  final String name;
  final String desc;
  final int price;

  @override
  State<DetailsScreen> createState() => _DetailsScreenState();
}

class _DetailsScreenState extends State<DetailsScreen> {
  double rate = 0;
  bool isFav = false;

  List fav = [];

  @override
  void initState() {
    super.initState();
    ge();
  }

  @override
  void didChangeDependencies() async {
    super.didChangeDependencies();
    await onPressed1();
    // fav =  Provider.of<ApiProvider>(context, listen: false).isMealFavorites(id);
    if (isFav) {
      onPressed1();
      setState(() {
        isFav = true;
      });
    } else {
      setState(() {
        isFav = false;
      });
      delFav();
    }
  }

  ge() async {
    await onPressed1();
    isFav = isMealFavorites(widget.id);
  }

  bool isMealFavorites(int id) {
    return fav.any((expert) {
      print(id);
      print(expert['id']);
      return id == expert['id'];
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: SafeArea(
          child: Column(
            children: [
              Stack(
                children: [
                  Container(
                    alignment: Alignment.center,
                    height: 300,
                    decoration: const BoxDecoration(
                      borderRadius:
                          BorderRadius.only(bottomRight: Radius.circular(100)),
                      image: DecorationImage(
                        fit: BoxFit.fill,
                        image: AssetImage('assets/images/1.jpg'),
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(7),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        IconButton(
                          onPressed: () {
                            Navigator.of(context).pop();
                          },
                          icon: const Icon(
                            Icons.arrow_back,
                            color: Color.fromRGBO(143, 148, 251, 1),
                            size: 30,
                          ),
                        ),
                        IconButton(
                          onPressed: onPressed,
                          icon: Icon(
                            isFav ? Icons.favorite : Icons.favorite_border,
                            color: Colors.red,
                            size: 30,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              const Text(
                'Shirt Name',
                textAlign: TextAlign.center,
                style: TextStyle(
                    color: Color.fromRGBO(143, 148, 251, 1),
                    fontWeight: FontWeight.bold,
                    fontSize: 25,
                    fontFamily: "Pacifico",
                ),
              ),
              const SizedBox(height: 10),
              const Text(
                'Lorem ipsum dolor sit amet. Et magnam rerum 33 alias culpa ut dolorum aspernatur qui autem dicta. Ut eveniet ducimus eum dolorum animi ex enim ducimus.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontFamily: "Pacifico",
                ),
              ),
              const SizedBox(height: 200),
              InkWell(
                onTap: () {
                  Get.to(Comments(id:widget.id));
                },
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 30),
                  child: Row(
                    children: const [
                      Text(
                        'Add Comment',
                        style: TextStyle(
                          fontFamily: "Pacifico",
                          color: Color.fromRGBO(143, 148, 251, 1),
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(width: 25,),
                      Icon(
                        Icons.comment,
                        color: Color.fromRGBO(143, 148, 251, 1),
                      )
                    ],
                  ),
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Text(
                        'Price :'.toUpperCase(),
                        style: const TextStyle(
                          color: Color.fromRGBO(143, 148, 251, 1),
                          fontSize: 20,
                          fontFamily: "Pacifico",
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(width: 5),
                      const Text(
                        '1000 \$',
                        style: TextStyle(
                          fontSize: 20,
                          fontFamily: "Pacifico",
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Text(
                        'rate :'.toUpperCase(),
                        style: const TextStyle(
                          fontFamily: "Pacifico",
                          color: Color.fromRGBO(143, 148, 251, 1),
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(width: 5),
                      Row(
                        children: const [
                          Icon(
                            Icons.star,
                            size: 25,
                            color: Colors.yellow,
                          ),
                          SizedBox(width: 5),
                          Text(
                            '4.8',
                            style: TextStyle(
                              fontSize: 18,
                              fontFamily: "Pacifico",
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      )
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Container(
                alignment: Alignment.topCenter,
                padding: const EdgeInsets.all(15),
                child: Row(
                  children: [
                    Expanded(
                      flex: 3,
                      child: ElevatedButton(
                        onPressed: () {
                          dialog(context);
                        },
                        style: ButtonStyle(
                          backgroundColor: MaterialStateProperty.all(
                              const Color.fromRGBO(143, 148, 251, 1)),
                          padding:
                              MaterialStateProperty.all(const EdgeInsets.all(10)),
                          shape: MaterialStateProperty.all(
                            const RoundedRectangleBorder(
                              borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(15),
                                bottomLeft: Radius.circular(15),
                              ),
                            ),
                          ),
                        ),
                        child: const Text(
                          'Add to Cart',
                          style: TextStyle(
                            color: Colors.white,
                            fontFamily: "Pacifico",
                            fontSize: 15,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ),
                    Expanded(
                      flex: 1,
                      child: Container(
                        padding: const EdgeInsets.all(10),
                        decoration: const BoxDecoration(
                          borderRadius: BorderRadius.only(
                            topRight: Radius.circular(15),
                            bottomRight: Radius.circular(15),
                          ),
                          color: Colors.white,
                        ),
                        child: const Icon(
                          Icons.shopping_cart,
                          size: 20,
                          color: Color.fromRGBO(143, 148, 251, 1),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  dialog(context) {
    showDialog(
      context: context,
      builder: (ctx) {
        return AlertDialog(
          title: const Text(
            'Rate This product',
            style: TextStyle(color: Color.fromRGBO(143, 148, 251, 1)),
          ),
          content: RatingBar(
            minRating: 0,
            maxRating: 5,
            initialRating: 0,
            allowHalfRating: true,
            ratingWidget: RatingWidget(
              full: const Icon(
                Icons.star,
                color: Colors.yellow,
              ),
              half: const Icon(
                Icons.star_half,
                color: Colors.yellow,
              ),
              empty: const Icon(
                Icons.star_border,
              ),
            ),
            onRatingUpdate: (double value) => rate = value,
            itemCount: 5,
            itemSize: 40,
            itemPadding: const EdgeInsets.symmetric(horizontal: 4),
            glow: false,
            updateOnDrag: true,
          ),
          actions: [
            TextButton(
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                  content: Text(
                    "Thanks for rating",
                    style: TextStyle(fontSize: 15),
                  ),
                  duration: Duration(seconds: 1),
                ));

                Navigator.of(ctx).pop();
              },
              child: const Text(
                'Done',
                style: TextStyle(
                    color: Color.fromRGBO(143, 148, 251, 1), fontSize: 20),
              ),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(ctx).pop();
                //Navigator.of(context).pop();
              },
              child: const Text(
                'Cancel',
                style: TextStyle(
                    color: Color.fromRGBO(143, 148, 251, 1), fontSize: 20),
              ),
            ),
          ],
        );
      },
    );
  }

  onPressed() async {
    if(isFav) {
      delFav();
    }
    else {
      add();
    }
    setState(() {
      isFav = !isFav;
    });
  }

  add() async {
    var response = await http.post(
      Uri.parse(
          'http://192.168.43.184:8000/api/favourites/add_fav_product'),
      headers: {
        'Accept': 'application/json',
        'Authorization': 'Bearer ${Token.token}'
      },
      body: {
        'product_id': '${widget.id}',
      },
    );
    if (response.statusCode == 200) {
      var hg = jsonDecode(response.body);
      print(hg);
    } else {
      print(response.body);
    }
  }

  Future onPressed1() async {
    var response = await http.get(
      Uri.parse('http://192.168.43.184:8000/api/favourites/get_fav_product'),
      headers: {
        'Accept': 'application/json',
        'Authorization': 'Bearer ${Token.token}'
      },
    );
    if (response.statusCode == 200) {
      var hg = jsonDecode(response.body);
      fav = hg['products'];
    } else {
      print(response.body);
    }
  }

  delFav() async {
    var response = await http.delete(
      Uri.parse(
          'http://192.168.43.184:8000/api/favourites/remove_fav_product'),
      headers: {
        'Accept': 'application/json',
        'Authorization': 'Bearer ${Token.token}'
      },
      body: {
        'product_id': '${widget.id}',
      },
    );
    if (response.statusCode == 200) {
      var hg = jsonDecode(response.body);
      print(hg);
    } else {
      print(response.body);
    }
  }


}