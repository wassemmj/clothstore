class  AppImageAsset {
  static const String rootImages = "assets/images" ;

  static const String onBoardingImageOne    = "$rootImages/onboarding1.PNG" ;
  static const String onBoardingImageTwo    = "$rootImages/onboarding2.PNG" ;
  static const String onBoardingImageThree  = "$rootImages/onboarding3.PNG" ;
  static const String onBoardingImageFour   = "$rootImages/onboarding4.PNG" ;

}